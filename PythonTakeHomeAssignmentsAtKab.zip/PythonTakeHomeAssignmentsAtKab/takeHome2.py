#Getting user input using input function
#int() converts user input to integer
num1=int(input("Enter 1st Number: "))
num2=int(input("Enter 2nd Number: "))
#performing operations
add=num1+num2
sub=num1-num2
mult=num1*num2
div=num1//num2
mod=num1%num2
#displaying output
print(f"Addition = {add}")
print(f"Subtraction = {sub}")
print(f"Multiplication = {mult}")
print(f"Division = {div}")
print(f"Modulus = {mod}")
