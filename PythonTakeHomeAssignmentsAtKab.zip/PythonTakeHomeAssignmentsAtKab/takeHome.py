 myName=input("Enter your name: ")
print(type(myName))

'''specify the data type first
before you allow user input'''

yearOfBirth=int(input('Provide your year of Birth: '))
print(type(yearOfBirth))
myHeight=float(input("Enter your height: "))
print(type(myHeight))
age=2024-yearOfBirth
print(f'Your current age is  {age} years')
age2=2029-yearOfBirth
print(f"You will be {age2} in 5 years time")
val=age*myHeight
print(f"{val} is the product of age and your height")
print(f"The  result of 'age'variable is: {age}")
print(f"The result of 'age2'variable is: {age2}")
print(f"The result of 'val'variable is: {val}")
print("Thanks to 'INDABAX AI CLUB KAB FOR THE PYHTON SERIES' ")
print('code written by "TC" ')